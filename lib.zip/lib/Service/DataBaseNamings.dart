
String USERS_COLLECTION = 'users';
String ORDERS_COLLECTION = 'orders';
String DEACTIVATED_ORDERS_COLLECTION = 'deactivated_orders';
String PAYMETNS_COLLECTION = 'payment';
String SETTINGS_COLLECTION = 'settings';
String MESSAGES_COLLECTION = 'messages';
String DEACTIVATED_USERS_COLLECTION = 'deactivated_users';
String DYNAMIC_CONSTANTS = 'dynamic_constants';


